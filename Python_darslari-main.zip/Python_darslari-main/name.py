aaa = isinstance(456,str)
print("pi is a float:", aaa)