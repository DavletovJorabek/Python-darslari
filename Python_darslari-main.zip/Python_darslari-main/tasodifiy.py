import random
while True:
    son = random.randint(1,10)
    kiritlilganSon = int(input("son: "))
    if kiritlilganSon == son:
        print("Yuttingiz")
        break
    else:
        print("Dam oling")