meva = {"nok", "banan", "shaftoli"}
