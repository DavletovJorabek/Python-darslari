meva = {"nok", "banan", "shaftoli"}
meva.add("Gilos")
print(meva)
