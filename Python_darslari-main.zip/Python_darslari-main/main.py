a = int(input("a="))
if a % 2 == 0:
    print('juft son')
else:
    print('toq son')
