ism = "Bekzod"
for i in ism:
    print(i)

