sonlar = [2, 3, 5, 1]
for number in sonlar:
    for i in range(number):
        print(number)