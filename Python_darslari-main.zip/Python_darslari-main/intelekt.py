
while True:
    age = int(input("Yosh"))
    if age>18 and age<100:
        break
    else:
        print("Yoshni qaytadan kiriting")

