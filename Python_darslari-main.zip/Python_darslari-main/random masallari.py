import random
name = ['Davron', 'Jamshid', 'Alibek']

tasdofiyiSon = random.randint(1, 3)
for i in name:
    index = name.index('Davron')
    print(index)




