a = [[1,2,3],[4,5,6],[7,8,9]]
b = [0,0,0]
for i in range(3):

    b[i] = a[i][i]
print(b)


