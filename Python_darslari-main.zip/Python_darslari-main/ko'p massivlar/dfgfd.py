matrix = [[1, 2], [3, 4]]
a = []
for raqam in matrix:
    for j in raqam:
        a.append(j)
print(a)
