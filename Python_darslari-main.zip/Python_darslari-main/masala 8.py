a = int(input("a="))
b = int(input("b="))
if a % 2 == 0:
    print('juft son')
else:
    print('toq son')

if b % 2 == 0:
    print('juft son')
else:
    print('toq son')