a = int(input("a="))
b = int(input("b="))
if b < a and b>a==0:
    print('a=')
else:
    print('b=')
