sonlar = [2, 3, 5, 1, 9]
kichikSon = sonlar[0]
for son in sonlar:
    if kichikSon > son:
        kichikSon = son
print(kichikSon)
