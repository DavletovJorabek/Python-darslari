import math
a = str(input())
b = a[-1]
c = a[0:len(a)-1]
print(b+c)