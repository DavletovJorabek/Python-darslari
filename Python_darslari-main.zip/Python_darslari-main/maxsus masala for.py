matn = "Gulla yaxshna ozbekiston"


ism = "Gulla yaxshna ozbekiston"
for i in matn:
    for j in ism:
        if i == j:
            print("yes")
            break
        else:
            print("no")
            break



