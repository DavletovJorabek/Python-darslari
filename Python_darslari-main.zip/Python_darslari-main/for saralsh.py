sonlar = [2, 3, 5, 1, 9, 6, 4, 0]
sonlar.sort(reverse=True)
print(sonlar)