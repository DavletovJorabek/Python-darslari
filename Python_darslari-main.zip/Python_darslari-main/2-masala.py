import math
a = 3
b = 4
c = 5
p = (a+b+c)/2
P = a+b+c
s = math.sqrt(p*(p-a)*(p-b)*(p-c))
print(f"Pirametr {P} Yuzasi {s}")
