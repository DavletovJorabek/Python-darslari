sonlar = [1,5,3,9,7,4,6]
a = []
b =[]
for i in sonlar:
    if i%2==0:
        a.append(i)


for i in sonlar:
    if i%2==1:
        a.append(i)
print(a)



