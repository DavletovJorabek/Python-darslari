sonlar = [1,5,3,9,7,4,6]
for i in sonlar:
    if i%2 == 0:
        print(i)
    