import random

car = ['Nexia','lasetti','Damas','Damas','Damas','lasetti','Damas','Nexia']
son = car.count('Damas')
print(son)
for i in car:
    son == car.remove('Damas')
print(car)

