#sonlar = [1, 2, 3, "jhgvdf"]

"""element = sonlar[3]
index = sonlar.index("jhgvdf")
print(index)
print(len(sonlar))"""
"""mevalar = ['Olam', 'Anor']
mevalar.append('Gilos')
print(mevalar)"""
"""sonlar = [1, 2, 3,]

sonlar = sonlar.clear()
print(sonlar)"""
sonlar = [1, 2, 3,]
"""sonlar1 = [4,5]
sonlar.extend(sonlar1)
print(sonlar)"""



