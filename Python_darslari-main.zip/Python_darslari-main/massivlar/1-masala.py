"""#yangi oquvchi
oquvchi = ['Bekzod', 'Ali', 'Davron']
oquvchi.append('Hasan')
print(oquvchi)
#ortasiga yangi oquvchi qoshish
oquvchi.insert(3,'Guli')
print(oquvchi)
print(len(oquvchi))
oquvchi.append('Hasan')
print(oquvchi)
print(oquvchi.count('Hasan'))
oquvchi2 = ['Jamshid', 'Lobar']
oquvchi.extend(oquvchi2)
print(oquvchi)
print(oquvchi.index('Lobar'))
print(oquvchi.clear())"""
"""oquvchi = ['Bekzod', 'Ali', 'Davron','Hasan']
oquvchiuzun = int(len(oquvchi)/2)

oquvchi.insert(oquvchiuzun,"guli")
print(oquvchi)
"""