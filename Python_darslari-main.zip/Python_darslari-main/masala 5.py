a = int(input("a="))
if a % 2 == 0:
    print('juft son')
elif a % 1 == 0:
    print('toq son')
