a = (1, 4, 6, 2)
# ruyxatni ichida bor yoki yuqligini tekshirish
"""if 8 in a:
    print("bor")
else:
    print("yuq")"""
print(max(a)+min(a))
