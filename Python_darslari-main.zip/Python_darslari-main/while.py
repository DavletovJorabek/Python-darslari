import math
a = int(input("a tomon:"))
b = int(input("a tomon:"))
while a<b:
    a = a+1
    if a% 2 ==0:
        print(a)




