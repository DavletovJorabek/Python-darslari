a = int(input("a="))

if a >= 1000 and a < 10000:
    print('to`rt xonali son')
else:
    print('to`rt xonali son emas')
